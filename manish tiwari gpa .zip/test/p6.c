
#include<stdio.h>
void main()
{int x,i,count=0,n;
printf("enter a number");
scanf("%d",&x);
for(i=0;i<n;i++)
{count++;
}
printf("%d",count);
}
