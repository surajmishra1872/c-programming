/*111111
22222
3333
444
55*/



#include<stdio.h>
void main()
{
	int i,j;
	for(i=1;i<=5;i++)
	{
	
	{for(j=1;j<=7-i;j++)
	printf("%d",i);
	}
	printf("\n");
}
}
